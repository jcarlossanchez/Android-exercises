package mx.com.lojack.login_sql_server;

import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {

    private EditText EdtUsuario;
    private EditText EdtPassword;
    private Button BtnIniciaSesion;
    private ProgressBar progressBar;
    private Connection con;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EdtUsuario = (EditText)findViewById(R.id.EdtUser);
        EdtPassword = (EditText)findViewById(R.id.EdtPassword);
        BtnIniciaSesion = (Button)findViewById(R.id.BtnIniciaSesion);
        progressBar = (ProgressBar)findViewById(R.id.progressBar);

        progressBar.setVisibility(View.GONE);

        BtnIniciaSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IniciaSesion iniciaSesion = new IniciaSesion();
                iniciaSesion.execute("");
            }
        });
    }

    public Connection conexionBD(){
        Connection conexion = null;
        try
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
            conexion = DriverManager.getConnection("jdbc:jtds:sqlserver://localhost;port=2433;databaseName=base;user=sa;password=password");
        }
        catch(Exception e)
        {
            Log.d("App", "Error: " + e.getMessage());
        }
        return conexion;
    }

    public class IniciaSesion extends AsyncTask<String,String,String>
    {
        String Mensaje = "";
        Boolean Resultado = false;

        @Override
        protected void onPreExecute() {
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            progressBar.setVisibility(View.GONE);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT).show();
                }
            });
            if(Resultado)
            {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            String usuario = EdtUsuario.getText().toString();
            String password = EdtPassword.getText().toString();

            if(usuario.trim().equals("") || password.trim().equals("") )
            {
                Mensaje = "Ingrese usuario y contraseña";
                Log.d("App", "Ingrese usuario y contraseña");
            }
            else
            {
                try
                {
                    con = conexionBD();
                    if (con == null)
                    {
                        Mensaje = "No se pudó conectar a la Base de Datos";
                        Log.d("App", "No se pudó conectar a la Base de Datos");
                    }
                    else
                    {
                        Log.d("App", "Se pudó conectar a la Base de Datos");
                        String queryLogin = "SELECT Usu_Nombre FROM Usuario WHERE Usu_Usuario = '" + usuario.toString() + "' AND Usu_Password = '" + password.toString() + "'";
                        Statement stmt = con.createStatement();
                        ResultSet rs = stmt.executeQuery(queryLogin);
                        if(rs.next())
                        {
                            Mensaje = "Inicio de sesion exitoso";
                            Log.d("App", "Inicio de sesion exitoso");
                            Resultado = true;
                            con.close();
                        }
                        else
                        {
                            Mensaje = "Usuario y contraseña invalidos";
                            Log.d("App", "Usuario y contraseña invalidos");
                            Resultado = false;
                            con.close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Resultado = false;
                    Mensaje = ex.getMessage();
                }
            }
            return Mensaje;
        }
    }
}