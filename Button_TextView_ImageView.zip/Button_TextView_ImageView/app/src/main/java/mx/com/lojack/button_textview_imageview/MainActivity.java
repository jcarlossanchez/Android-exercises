package mx.com.lojack.button_textview_imageview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView TextoA;
    private ImageView ImagenA;
    private Button BotonA, BotonB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextoA = (TextView)findViewById(R.id.TextViewA);
        ImagenA = (ImageView)findViewById(R.id.ImageViewA);
        BotonA = (Button)findViewById(R.id.ButtonTexto);
        BotonB = (Button)findViewById(R.id.ButtonImage);

        BotonA.setOnClickListener(this);
        BotonB.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.ButtonTexto:
                TextoA.setText("Click en botón Texto");
                break;
            case R.id.ButtonImage:
                ImagenA.setImageResource(R.drawable.escorpion);
                break;
            default:
                break;
        }
    }
}
