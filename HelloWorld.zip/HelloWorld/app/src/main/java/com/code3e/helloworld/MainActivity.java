package com.code3e.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView textView;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Accesamos a las vistas mediante su id

        textView = (TextView)findViewById(R.id.textView);
        button = (Button)findViewById(R.id.button);

        //Implementamos un Listener (interface) al boton

        /*
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                textView.setText("Hola mundo...");

            }
        });
        */

        button.setOnClickListener(this);

    }

    // Creamos una funcion y se la asignamos al boton en el XML
    //View view: es el boton que vendrá como argumento

    public void buttonClicked(View view){
        textView.setText("Test clic");
    }


    @Override
    public void onClick(View view) {
        textView.setText("hello Android");
    }
}













